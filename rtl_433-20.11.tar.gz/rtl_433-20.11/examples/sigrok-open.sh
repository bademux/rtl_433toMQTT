#!/bin/bash

echo 'Please use "rtl_433 [-s <samplerate>] -W <output>.sr -r <input>.cu8"'
